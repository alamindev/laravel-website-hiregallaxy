<?php

/* @var $factory \Illuminate\Database\Eloquent\Factory */

use App\Aptitude;
use Faker\Generator as Faker;

$factory->define(Aptitude::class, function (Faker $faker) {
    return [
        //
    ];
});
