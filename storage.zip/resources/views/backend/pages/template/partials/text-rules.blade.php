{{--  <a href="#" data-toggle="tooltip" title="Select text and ctrl+b to bold, ctrl+i to italic 
and right click to insert link and others">
    <i class="fa fa-info-circle text-danger"></i>
</a>  --}}