{{--  <script src="{{ asset('admin-asset/js/tinymce/tiny_old.min.js') }}"></script> --}}

{{--  <script src="https://cdn.tiny.cloud/1/qagffr3pkuv17a8on1afax661irst1hbr4e6tbv888sz91jc/tinymce/5/tinymce.min.js">  --}}

{{--  </script>  --}}



<style>

    .mce-branding-powered-by {

        display: none;

    }



    .mce-statusbar .mce-container-body {

        display: none;

    }



    .mce-panel {

        border: 0 solid #9e9e9e30;

        border-bottom: 0px !important;

    }



    .mce-container,

    .mce-container *,

    .mce-widget,

    .mce-widget *,

    .mce-reset {

        border-right: 1px solid transparent;

    }



    .mce-branding-powered-by {

        display: none;

    }



    .mce-statusbar .mce-container-body {

        display: none;

    }

</style>

{{--  

tinymce.init({

    selector:'.template' ,

    plugins: 'codesample autoresize code print preview fullpage searchreplace autolink directionality visualblocks visualchars fullscreen image link media codesample table charmap hr pagebreak nonbreaking anchor toc insertdatetime advlist lists textcolor wordcount imagetools contextmenu colorpicker textpattern',

    autoresize_bottom_margin: 0,

    image_advtab: true,

    menubar:false,

    setup: function(editor){

      editor.on('keyup', function(e){

        vm.model = editor.getContent();

      })

    }

  });  --}}