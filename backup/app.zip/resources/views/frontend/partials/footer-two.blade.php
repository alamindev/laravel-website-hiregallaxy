 
<!-- Apply Job Modals -->

@include('frontend.partials.apply-job-modal')

@include('frontend.partials.apply-update-job-modal')

<!-- Apply Job Modals -->





<div class="modal animated fadeIn" id="signInModal">

	@include('frontend.partials.signin-modal')

</div>



<section class="footer-bottom-section">  


</section>

<!-- Footer Section -->