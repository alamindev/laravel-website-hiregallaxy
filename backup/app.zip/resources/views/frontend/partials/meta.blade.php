<meta name="keywords" content="job, hire employer, search candidate , free ,candidates, apply, test ,requiter, employer, candidate ,  business, joblrs"/>
<meta name="description" content="Joblrs.com is one of the most trusted online source for job opportunities. Apply for your desired job, get career advice and improve your skill through trainning."/>
<meta name="subject" content="job opportunities">  
<meta name="robots" content="index,follow" />      
<meta name="url" content="https://joblrs.com/">
<meta name="identifier-URL" content="https://www.joblrs.com/">       
<meta http-equiv="Cache-Control" content="no-cache">
 
    