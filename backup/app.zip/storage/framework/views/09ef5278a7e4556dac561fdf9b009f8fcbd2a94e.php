<?php $__env->startSection('title'); ?>
Candidates | <?php echo e(App\Models\Setting::first()->site_title); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('stylesheets'); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<section class="employer-page sec-pad">
	<div class="container">
		<h5 class="text-theme bold mb-4 float-left">We have found <span class="text-yellow"><?php echo e(count($users)); ?></span>
			Matches for you </h5>
		<?php if(Route::is('candidates.search')): ?>
		<div class="float-right">
			<div class="search-criteria">
				<span class="text-theme">
					Search By -
				</span>
				<?php if(isset($_GET['search']) && $_GET['search'] != ''): ?>
				Search -
				<span class="badge badge-primary font16">
					<?php echo e($_GET['search']); ?>

				</span>
				<?php endif; ?>
				<?php if(isset($_GET['category']) && $_GET['category'] != ''): ?>
				Category -
				<span class="badge badge-primary font16">
					<?php echo e($_GET['category']); ?>

				</span>
				<?php endif; ?>
				<?php if(isset($_GET['country']) && $_GET['country'] != ''): ?>
				City -
				<span class="badge badge-primary font16">
					<?php echo e($_GET['country']); ?>

				</span>
				<?php endif; ?>

				<?php if(isset($_GET['experience']) && $_GET['experience'] != ''): ?>
				Experience -
				<span class="badge badge-primary font16">
					<?php echo e($_GET['experience']); ?>

				</span>
				<?php endif; ?>
			</div>
		</div>
		<?php endif; ?>
		<div class="clearfix"></div>
		<div class="row">
			<div class="col-md-4">
				<div class="left-sidebar">
					<div class="toggleNav">
						<button class="btn btn-outline-secondary btn-toggle"><i class="fa fa-bars"></i></button>
					</div>
					<div class="toggleNav2">
						<button class="btn btn-outline-secondary btn-toggle"><i class="fa fa-times"></i></button>
					</div>
					<div id="left-sidebar">
						<?php echo $__env->make('frontend.pages.partials.candidate-search', ['route' => route('candidates.search') ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
					</div>

				</div>
			</div>
			<div class="col-md-8">
				<div class="page-employer">
					<div class="employee-header-section">
						<div class="float-right">
							<span class="text-theme">
								You're watching <span class="count-text"><?php echo e($pageNoText); ?></span>
							</span>
						</div>
						<div class="clearfix"></div>
					</div>

					<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $single_user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php echo $__env->make('frontend.pages.partials.candidate-single', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

					<?php if(count($users) == 0): ?>
					<div class="alert alert-danger mt-2">
						<strong>Sorry !!</strong>
						<br>
						<p>We have not found any employee for this query now !!</p>
					</div>
					<?php endif; ?>

					<div class="page-pagination mt-4">
						<?php echo e($users->links()); ?>

					</div>
				</div>
			</div>
		</div>
	</div>
</section>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
<script>
	$("input:checkbox").on('click', function() {
		var $box = $(this);
		if ($box.is(":checked")) {
			var group = "input:checkbox[name='" + $box.attr("name") + "']";
			$(group).prop("checked", false);
			$box.prop("checked", true);
		} else {
			$box.prop("checked", false);
		}
	});

	function submitSearch(event){
		// alert('Searching');
		 $("#cadidateSearchForm").submit();
	}
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\hiregalaxy_itclan\resources\views/frontend/pages/candidates/index.blade.php ENDPATH**/ ?>