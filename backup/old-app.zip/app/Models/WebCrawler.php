<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class WebCrawler extends Model
{
    public $fillable = ['name'];
}
